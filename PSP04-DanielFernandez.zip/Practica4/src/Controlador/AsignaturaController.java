package Controlador;

import Modelo.Alumno;
import Modelo.Asignatura;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AsignaturaController {

    // Método para obtener las asignaturas de un alumno
    public static List<Asignatura> obtenerAsignaturas(int aluNumero) {
        List<Asignatura> asignaturas = new ArrayList<>();
        String query = "SELECT * FROM Asignatura WHERE aluNumero = ?"; // Usar aluNumero en lugar de numeroAlumno
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, aluNumero); // Pasar el aluNumero como parámetro a la consulta
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Asignatura asignatura = new Asignatura(
                        rs.getInt("codigo"), // Asignar el código de la asignatura
                        rs.getString("nombre"), // Asignar el nombre de la asignatura
                        rs.getDouble("nota"), // Asignar la nota de la asignatura
                        rs.getInt("aluNumero") // Asignar el número del alumno
                );
                asignaturas.add(asignatura);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return asignaturas;
    }

    // Método para obtener las asignaturas de un alumno dado su número
    public static List<Asignatura> obtenerAsignaturasPorAlumno(int numeroAlumno) {
        List<Asignatura> asignaturas = new ArrayList<>();
        String query = "SELECT * FROM Asignatura WHERE aluNumero = ?"; // Se usa aluNumero para obtener las asignaturas de un alumno
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, numeroAlumno); // Establecer el número del alumno en la consulta
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                // Crear asignatura y agregarla a la lista
                Asignatura asignatura = new Asignatura(
                        rs.getInt("codigo"), // Código de la asignatura
                        rs.getString("nombre"), // Nombre de la asignatura
                        rs.getDouble("nota"), // Nota de la asignatura
                        rs.getInt("aluNumero") // Número del alumno
                );
                asignaturas.add(asignatura);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return asignaturas;  // Devuelve la lista de asignaturas asociadas al alumno
    }

    // Método para actualizar la nota de una asignatura
    public static void actualizarNota(int codigoAsignatura, double nuevaNota) {
        // Verificamos si la nueva nota es diferente de la actual para evitar actualizaciones innecesarias
        double notaActual = obtenerNotaActual(codigoAsignatura);

        if (notaActual != nuevaNota) {
            String query = "UPDATE Asignatura SET nota = ? WHERE codigo = ?";

            try (Connection conn = ConexionDB.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setDouble(1, nuevaNota);        // Asigna la nueva nota
                stmt.setInt(2, codigoAsignatura);    // Asigna el código de la asignatura a actualizar
                int filasAfectadas = stmt.executeUpdate();   // Ejecuta la actualización

                if (filasAfectadas > 0) {
                    System.out.println("Nota actualizada exitosamente.");
                } else {
                    System.out.println("No se encontró la asignatura o no se actualizó.");
                }
            } catch (SQLException e) {
                System.err.println("Error al actualizar la nota: " + e.getMessage());
            }
        } else {
            System.out.println("La nota no ha cambiado. No se realizó la actualización.");
        }
    }

    // Método adicional para obtener la nota actual de la asignatura
    private static double obtenerNotaActual(int codigoAsignatura) {
        String query = "SELECT nota FROM Asignatura WHERE codigo = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, codigoAsignatura);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("nota");
            } else {
                System.out.println("Asignatura no encontrada.");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener la nota actual: " + e.getMessage());
        }
        return -1;  // Retorna -1 si no se encontró la asignatura
    }

    // Método para obtener el alumno por su número
    public static Alumno obtenerAlumno(int numero) {
            String query = "SELECT * FROM Alumno WHERE numero = ?";  // Asegúrate que la consulta esté ajustada a tu base de datos
            
            try (Connection conn = ConexionDB.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                
                stmt.setInt(1, numero);  // Establecer el número de alumno en la consulta
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    int numeroAlumno = rs.getInt("numero");
                    String usuario = rs.getString("usuario");
                    String contraseña = rs.getString("contraseña");
                    Date fechaNacimiento = rs.getDate("fecha_nacimiento");  // Asegúrate que el nombre de la columna sea correcto
                    double notaMedia = rs.getDouble("nota_media");
                    String imagen = rs.getString("imagen");  // Aquí tomamos la imagen (ruta o nombre del archivo)
                    
                    // Devolver el objeto Alumno con los datos obtenidos
                    return new Alumno(numeroAlumno, usuario, contraseña, fechaNacimiento, notaMedia, imagen);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;  // Si no se encuentra el alumno
    }

}
