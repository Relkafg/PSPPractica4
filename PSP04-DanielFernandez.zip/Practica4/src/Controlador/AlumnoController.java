package Controlador;

import Modelo.Alumno;
import Modelo.Asignatura;

import java.sql.*;
import java.util.Date;
import java.util.List;

public class AlumnoController {

    // Método para obtener el alumno por su número
    public static Alumno obtenerAlumno(int numero) {
        String query = "SELECT * FROM Alumno WHERE numero = ?";  // Asegúrate que la consulta esté ajustada a tu base de datos
        
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, numero);  // Establecer el número de alumno en la consulta
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int numeroAlumno = rs.getInt("numero");
                String usuario = rs.getString("usuario");
                String contraseña = rs.getString("contraseña");
                Date fecha_nacimiento = rs.getDate("fecha_nacimiento");
                double notaMedia = rs.getDouble("nota_media");
                String imagen = rs.getString("imagen");  // Aquí tomamos la imagen (ruta o nombre del archivo)
                
                // Devolver el objeto Alumno con los datos obtenidos
                return new Alumno(numeroAlumno, usuario, contraseña, fecha_nacimiento, notaMedia, imagen);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;  // Si no se encuentra el alumno
    }

    // Método para actualizar la fecha de nacimiento del alumno
    public static boolean actualizarFechaNacimiento(int numeroAlumno, Date nuevaFecha) {
        String query = "UPDATE Alumno SET fecha_nacimiento = ? WHERE numero = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Convertir la fecha de tipo Date a SQL Date
            java.sql.Date sqlDate = new java.sql.Date(nuevaFecha.getTime());

            stmt.setDate(1, sqlDate);
            stmt.setInt(2, numeroAlumno);

            int filasActualizadas = stmt.executeUpdate();
            return filasActualizadas > 0;  // Si se actualizó al menos una fila, el método devuelve true
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // En caso de error, devolver false
        }
    }

    // Método para calcular la nota media del alumno
    public static double calcularNotaMedia(int numeroAlumno) {
        double sumaNotas = 0;
        int numAsignaturas = 0;

        // Suponiendo que existe un controlador para las asignaturas, obtenemos las asignaturas del alumno
        // Nota: Este método depende de que tengas acceso a las asignaturas de ese alumno
        List<Asignatura> asignaturas = AsignaturaController.obtenerAsignaturasPorAlumno(numeroAlumno);
        
        // Calcular la suma de las notas
        for (Asignatura asignatura : asignaturas) {
            sumaNotas += asignatura.getNota();
            numAsignaturas++;
        }

        // Si hay asignaturas, calculamos la media
        if (numAsignaturas > 0) {
            return sumaNotas / numAsignaturas;
        } else {
            return 0;  // Si no hay asignaturas, la media será 0
        }
    }

    // Método para actualizar la nota media en la base de datos
    public static boolean actualizarNotaMedia(int numeroAlumno, double nuevaNotaMedia) {
        String query = "UPDATE Alumno SET nota_media = ? WHERE numero = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setDouble(1, nuevaNotaMedia);
            stmt.setInt(2, numeroAlumno);

            int filasActualizadas = stmt.executeUpdate();
            return filasActualizadas > 0;  // Si se actualizó al menos una fila, el método devuelve true
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // En caso de error, devolver false
        }
    }
}
