package Modelo;

import java.util.Date;

public class Alumno {
    private int numero;  // Número de alumno
    private String usuario;  // Nombre de usuario
    private String contraseña;  // Contraseña del alumno
    private Date fechaNacimiento;  // Fecha de nacimiento
    private double notaMedia;  // Nota media del alumno
    private String imagen;  // Ruta o nombre de la imagen del alumno

    // Constructor
    public Alumno(int numero, String usuario, String contraseña, Date fechaNacimiento, double notaMedia, String imagen) {
        this.numero = numero;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.fechaNacimiento = fechaNacimiento;
        this.notaMedia = notaMedia;
        this.imagen = imagen;
    }

    // Getters y setters
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        this.notaMedia = notaMedia;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
}
