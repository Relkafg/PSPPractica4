package Vista;

import Controlador.ConexionDB;
import Controlador.AlumnoController;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PanelValidar extends JPanel {
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;
    private JButton btnValidar;
    private MainFrame mainFrame; // Referencia al MainFrame

    public PanelValidar(MainFrame mainFrame) {
        this.mainFrame = mainFrame; // Guardar la referencia al MainFrame

        setLayout(new GridLayout(3, 2));
        add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        add(txtUsuario);
        add(new JLabel("Contraseña:"));
        txtContraseña = new JPasswordField();
        add(txtContraseña);
        btnValidar = new JButton("Validar");
        add(btnValidar);

        btnValidar.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contraseña = new String(txtContraseña.getPassword());

            // Verificar la validación del usuario
            if (validarUsuario(usuario, contraseña)) {
                int numeroAlumno = obtenerNumeroAlumno(usuario, contraseña);
                if (numeroAlumno != -1) {
                    // Comunicación con MainFrame
                    //mainFrame.setNumeroAlumno(numeroAlumno);
                    //mainFrame.habilitarOpcionesMenu(); // Habilitar menús
                    //mainFrame.mostrarPanelDetalle();   // Cambiar al panel de detalles
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private boolean validarUsuario(String usuario, String contraseña) {
        String query = "SELECT * FROM Alumno WHERE usuario = ? AND contraseña = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contraseña);
            ResultSet rs = stmt.executeQuery();

            return rs.next(); // Si encuentra un registro, devuelve true
        } catch (SQLException e) {
            e.printStackTrace(); // Imprimir el error SQL para depuración
            return false;
        }
    }

    private int obtenerNumeroAlumno(String usuario, String contraseña) {
        String query = "SELECT numero FROM Alumno WHERE usuario = ? AND contraseña = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contraseña);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("numero");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Alumno no encontrado
    }
}
