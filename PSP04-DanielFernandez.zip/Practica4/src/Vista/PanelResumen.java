package Vista;

import Modelo.Alumno;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;

public class PanelResumen extends JPanel {

    public PanelResumen(Alumno alumno) {
        setLayout(new BorderLayout());

        // Título del panel
        JLabel lblTitulo = new JLabel("Resumen del Alumno", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(lblTitulo, BorderLayout.NORTH);

        // Panel para mostrar los detalles del alumno
        JPanel panelDetalles = new JPanel(new GridLayout(5, 2, 10, 10)); // 5 filas, 2 columnas con espacio entre celdas
        panelDetalles.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Márgenes alrededor del panel

        // Formatear la fecha de nacimiento
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String fechaNacimiento = alumno.getFechaNacimiento() != null 
                ? dateFormat.format(alumno.getFechaNacimiento()) 
                : "No disponible";

        // Agregar los detalles al panel
        panelDetalles.add(new JLabel("Número de Alumno:"));
        panelDetalles.add(new JLabel(String.valueOf(alumno.getNumero())));
        panelDetalles.add(new JLabel("Usuario:"));
        panelDetalles.add(new JLabel(alumno.getUsuario()));
        panelDetalles.add(new JLabel("Fecha de Nacimiento:"));
        panelDetalles.add(new JLabel(fechaNacimiento));
        panelDetalles.add(new JLabel("Nota Media:"));
        panelDetalles.add(new JLabel(String.format("%.2f", alumno.getNotaMedia())));

        // Mostrar la imagen
        JLabel lblImagen = new JLabel();
        if (alumno.getImagen() != null && !alumno.getImagen().isEmpty()) {
            try {
                ImageIcon icon = new ImageIcon(alumno.getImagen());
                Image img = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                lblImagen.setIcon(new ImageIcon(img));
            } catch (Exception e) {
                lblImagen.setText("Imagen no disponible");
            }
        } else {
            lblImagen.setText("Imagen no disponible");
        }
        panelDetalles.add(new JLabel("Imagen:"));
        panelDetalles.add(lblImagen);

        add(panelDetalles, BorderLayout.CENTER);

        // Pie de página
        JLabel lblPie = new JLabel("Datos actualizados", SwingConstants.CENTER);
        lblPie.setFont(new Font("Arial", Font.ITALIC, 12));
        lblPie.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(lblPie, BorderLayout.SOUTH);
    }
}
