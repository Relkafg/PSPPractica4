package Vista;

import Controlador.AsignaturaController;
import Modelo.Asignatura;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PanelDetalle extends JPanel {
    private int currentAsignaturaIndex = 0;
    private List<Asignatura> asignaturas;

    public PanelDetalle(int numeroAlumno) {
        setLayout(new BorderLayout());

        asignaturas = AsignaturaController.obtenerAsignaturas(numeroAlumno);
        mostrarAsignatura();
    }

    private void mostrarAsignatura() {
        removeAll();

        if (asignaturas.isEmpty()) {
            add(new JLabel("No hay asignaturas para mostrar."), BorderLayout.CENTER);
        } else {
            Asignatura asignatura = asignaturas.get(currentAsignaturaIndex);

            JPanel panelInfo = new JPanel(new GridLayout(2, 2));
            panelInfo.add(new JLabel("Asignatura:"));
            panelInfo.add(new JLabel(asignatura.getNombre()));
            panelInfo.add(new JLabel("Nota:"));
            JTextField txtNota = new JTextField(String.valueOf(asignatura.getNota()));
            panelInfo.add(txtNota);

            add(panelInfo, BorderLayout.CENTER);

            JPanel panelBotones = new JPanel();
            JButton btnAnterior = new JButton("Anterior");
            JButton btnSiguiente = new JButton("Siguiente");

            btnAnterior.addActionListener(e -> {
                if (currentAsignaturaIndex > 0) {
                    currentAsignaturaIndex--;
                    mostrarAsignatura();
                }
            });

            btnSiguiente.addActionListener(e -> {
                if (currentAsignaturaIndex < asignaturas.size() - 1) {
                    currentAsignaturaIndex++;
                    mostrarAsignatura();
                }
            });

            JButton btnGuardar = new JButton("Guardar Nota");
            btnGuardar.addActionListener(e -> {
                try {
                    double nuevaNota = Double.parseDouble(txtNota.getText());
                    asignatura.setNota(nuevaNota);
                    AsignaturaController.actualizarNota(asignatura.getCodigo(), nuevaNota);
                    JOptionPane.showMessageDialog(this, "Nota actualizada correctamente");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Nota no válida", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            panelBotones.add(btnAnterior);
            panelBotones.add(btnSiguiente);
            panelBotones.add(btnGuardar);
            add(panelBotones, BorderLayout.SOUTH);
        }

        revalidate();
        repaint();
    }
}
