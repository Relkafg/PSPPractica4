package Vista;

import Controlador.AlumnoController;
import Controlador.AsignaturaController;
import Controlador.ConexionDB;
import Modelo.Asignatura;
import Modelo.Alumno;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Date;
import java.util.List;

public class MainFrame extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;
    private JButton btnValidar;
    private JList<String> listAsignaturas;
    private JPanel panelPrincipal;
    private DefaultListModel<String> listModel;

    private JMenuItem itemEntrar;
    private JMenuItem itemSalir;
    private JMenuItem itemDetalle;
    private JMenuItem itemResumen;
    private JMenuItem itemAcercaDe;

    private int currentAsignaturaIndex = 0;  // Índice de la asignatura actual
    private List<Asignatura> asignaturas; // Lista de asignaturas del alumno validado
    private int numeroAlumno;

    public MainFrame() {
        setTitle("Gestión Escolar");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Crear el menú
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // Crear las opciones del menú
        JMenu menuValidar = new JMenu("Validar");
        JMenu menuVisualizar = new JMenu("Visualizar");
        JMenu menuAcercaDe = new JMenu("Acerca de");

        // Agregar las opciones de "Validar"
        itemEntrar = new JMenuItem("Entrar");
        itemEntrar.addActionListener(e -> mostrarPanelValidar());
        itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0));
        menuValidar.add(itemEntrar);
        menuValidar.add(itemSalir);

        // Agregar las opciones de "Visualizar"
        itemDetalle = new JMenuItem("Detalle");
        itemDetalle.addActionListener(e -> mostrarPanelDetalle());
        itemResumen = new JMenuItem("Resumen");
        itemResumen.addActionListener(e -> mostrarPanelResumen());
        menuVisualizar.add(itemDetalle);
        menuVisualizar.add(itemResumen);

        // Agregar la opción "Acerca de"
        itemAcercaDe = new JMenuItem("Acerca de");
        itemAcercaDe.addActionListener(e -> mostrarAcercaDe());

        // Desactivamos inicialmente las opciones "Visualizar" y "Acerca de"
        itemDetalle.setEnabled(false);
        itemResumen.setEnabled(false);
        itemAcercaDe.setEnabled(true);

        menuAcercaDe.add(itemAcercaDe);

        // Agregar los menús al menú bar
        menuBar.add(menuValidar);
        menuBar.add(menuVisualizar);
        menuBar.add(menuAcercaDe);

        // Panel principal que cambiará según la opción seleccionada
        panelPrincipal = new JPanel();
        add(panelPrincipal, BorderLayout.CENTER);
    }

    private void mostrarPanelValidar() {
        // Panel de validación
        JPanel panelValidar = new JPanel();
        panelValidar.setLayout(new GridLayout(3, 2));
        panelValidar.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        panelValidar.add(txtUsuario);
        panelValidar.add(new JLabel("Contraseña:"));
        txtContraseña = new JPasswordField();
        panelValidar.add(txtContraseña);
        btnValidar = new JButton("Validar");
        btnValidar.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contraseña = new String(txtContraseña.getPassword());

            // Verificar la validación del usuario
            if (validarUsuario(usuario, contraseña)) {
                numeroAlumno = obtenerNumeroAlumno(usuario, contraseña);  // Almacenar el numero de alumno
                if (numeroAlumno != -1) {
                    // Si la validación es exitosa, habilitamos las opciones de "Visualizar" y "Acerca de"
                    itemDetalle.setEnabled(true);
                    itemResumen.setEnabled(true);
                    itemAcercaDe.setEnabled(true);

                    // Obtener las asignaturas del alumno y mostrar el panel de detalle
                    asignaturas = AsignaturaController.obtenerAsignaturas(numeroAlumno);
                    mostrarPanelDetalle();  // Mostrar el panel de detalle
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panelValidar.add(btnValidar);

        // Cambiar el contenido del panel principal
        panelPrincipal.removeAll();
        panelPrincipal.add(panelValidar);
        panelPrincipal.revalidate();
        panelPrincipal.repaint();
    }

    private boolean validarUsuario(String usuario, String contraseña) {
        String query = "SELECT * FROM Alumno WHERE usuario = ? AND contraseña = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contraseña);
            ResultSet rs = stmt.executeQuery();

            return rs.next(); // Si encuentra un registro, devuelve true
        } catch (SQLException e) {
            e.printStackTrace(); // Imprimir el error SQL para depuración
            return false;
        }
    }

    private int obtenerNumeroAlumno(String usuario, String contraseña) {
        String query = "SELECT numero FROM Alumno WHERE usuario = ? AND contraseña = ?";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contraseña);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("numero");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Alumno no encontrado
    }

    private void mostrarPanelDetalle() {
        // Panel de detalle de asignaturas
        JPanel panelDetalle = new JPanel();
        panelDetalle.setLayout(new BorderLayout());

        // Mostrar la asignatura actual
        Asignatura asignatura = asignaturas.get(currentAsignaturaIndex);

        // Panel de detalles de la asignatura
        JPanel panelAsignatura = new JPanel();
        panelAsignatura.setLayout(new GridLayout(2, 2));

        panelAsignatura.add(new JLabel("Asignatura:"));
        panelAsignatura.add(new JLabel(asignatura.getNombre()));

        JTextField txtNota = new JTextField(String.valueOf(asignatura.getNota()));
        panelAsignatura.add(new JLabel("Nota:"));
        panelAsignatura.add(txtNota);

        panelDetalle.add(panelAsignatura, BorderLayout.CENTER);

        // Panel de navegación con los botones de "Anterior" y "Siguiente"
        JPanel panelNavegacion = new JPanel();
        JButton btnAnterior = new JButton("Anterior");
        btnAnterior.addActionListener(e -> {
            if (currentAsignaturaIndex > 0) {
                currentAsignaturaIndex--;
                mostrarPanelDetalle(); // Volver a renderizar el panel
            }
        });

        JButton btnSiguiente = new JButton("Siguiente");
        btnSiguiente.addActionListener(e -> {
            if (currentAsignaturaIndex < asignaturas.size() - 1) {
                currentAsignaturaIndex++;
                mostrarPanelDetalle(); // Volver a renderizar el panel
            }
        });

        // Actualizar la habilitación de los botones
        actualizarBotones(btnAnterior, btnSiguiente);

        panelNavegacion.add(btnAnterior);
        panelNavegacion.add(btnSiguiente);
        panelDetalle.add(panelNavegacion, BorderLayout.SOUTH);

        // Botón para guardar la nota actualizada
        JButton btnGuardar = new JButton("Guardar Nota");
        btnGuardar.addActionListener(e -> {
            double nuevaNota;
            try {
                nuevaNota = Double.parseDouble(txtNota.getText());
                asignatura.setNota(nuevaNota);  // Actualizar la nota en el objeto
                AsignaturaController.actualizarNota(asignatura.getCodigo(), nuevaNota);  // Actualizar en la base de datos

                // Actualizar la nota en la lista de asignaturas
                asignaturas.get(currentAsignaturaIndex).setNota(nuevaNota);

                // Recalcular la nota media
                double nuevaNotaMedia = calcularNotaMedia(numeroAlumno); // Recalcular la nota media después de actualizar la nota
                AlumnoController.actualizarNotaMedia(numeroAlumno, nuevaNotaMedia);  // Actualizar en la base de datos del alumno

                JOptionPane.showMessageDialog(this, "Nota actualizada correctamente. Nota media actualizada.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese una nota válida", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panelDetalle.add(btnGuardar, BorderLayout.NORTH);

        // Cambiar el contenido del panel principal
        panelPrincipal.removeAll();
        panelPrincipal.add(panelDetalle);
        panelPrincipal.revalidate();
        panelPrincipal.repaint();
    }

    private void actualizarBotones(JButton btnAnterior, JButton btnSiguiente) {
        // Desactivar el botón "Anterior" si estamos en la primera asignatura
        if (currentAsignaturaIndex == 0) {
            btnAnterior.setEnabled(false);
        } else {
            btnAnterior.setEnabled(true);
        }

        // Desactivar el botón "Siguiente" si estamos en la última asignatura
        if (currentAsignaturaIndex == asignaturas.size() - 1) {
            btnSiguiente.setEnabled(false);
        } else {
            btnSiguiente.setEnabled(true);
        }
    }


    private void mostrarPanelResumen() {
        // Panel de resumen del alumno
        JPanel panelResumen = new JPanel();
        panelResumen.setLayout(new BorderLayout());

        // Usar el número de alumno validado
        Alumno alumno = AlumnoController.obtenerAlumno(numeroAlumno);

        if (alumno != null) {
            // Mostrar los detalles del alumno
            JLabel lblResumen = new JLabel("Resumen del Alumno");
            lblResumen.setFont(new Font("Arial", Font.BOLD, 16));
            panelResumen.add(lblResumen, BorderLayout.NORTH);

            // Panel de detalles del alumno
            JPanel panelDetalles = new JPanel();
            panelDetalles.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 5, 5, 5); // Espaciado entre los elementos

            // Mostrar el nombre del alumno
            gbc.gridx = 0;
            gbc.gridy = 0;
            panelDetalles.add(new JLabel("Nombre:"), gbc);
            gbc.gridx = 1;
            panelDetalles.add(new JLabel(alumno.getUsuario()), gbc);

            // Mostrar la fecha de nacimiento con un Spinner
            gbc.gridx = 0;
            gbc.gridy = 1;
            panelDetalles.add(new JLabel("Fecha de Nacimiento:"), gbc);

            SpinnerDateModel model = new SpinnerDateModel();
            JSpinner dateSpinner = new JSpinner(model);
            JSpinner.DateEditor editor = new JSpinner.DateEditor(dateSpinner, "dd/MM/yyyy");
            dateSpinner.setEditor(editor);
            dateSpinner.setValue(alumno.getFechaNacimiento());
            gbc.gridx = 1;
            panelDetalles.add(dateSpinner, gbc);

            // Botón para guardar la nueva fecha de nacimiento
            JButton btnGuardarFecha = new JButton("Guardar Fecha");
            btnGuardarFecha.addActionListener(e -> {
                Date nuevaFecha = (Date) dateSpinner.getValue();
                if (nuevaFecha != null) {
                    alumno.setFechaNacimiento(nuevaFecha);
                    boolean actualizado = AlumnoController.actualizarFechaNacimiento(numeroAlumno, nuevaFecha);
                    if (actualizado) {
                        JOptionPane.showMessageDialog(this, "Fecha de nacimiento actualizada correctamente");
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al actualizar la fecha de nacimiento", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Por favor, selecciona una fecha válida", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2;
            panelDetalles.add(btnGuardarFecha, gbc);
            gbc.gridwidth = 1;

            // Mostrar la nota media
            gbc.gridx = 0;
            gbc.gridy = 3;
            panelDetalles.add(new JLabel("Nota Media:"), gbc);
            gbc.gridx = 1;
            panelDetalles.add(new JLabel(String.format("%.2f", calcularNotaMedia(numeroAlumno))), gbc);

            // Obtener asignaturas del alumno
            List<Asignatura> asignaturas = AsignaturaController.obtenerAsignaturas(numeroAlumno);
            String[] columnNames = {"Nombre", "Nota"};
            Object[][] data = new Object[asignaturas.size()][2];
            for (int i = 0; i < asignaturas.size(); i++) {
                data[i][0] = asignaturas.get(i).getNombre();
                data[i][1] = asignaturas.get(i).getNota();
            }
            JTable tablaAsignaturas = new JTable(data, columnNames);
            JScrollPane scrollPane = new JScrollPane(tablaAsignaturas);
            scrollPane.setBorder(BorderFactory.createTitledBorder("Asignaturas"));
            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 2;
            panelDetalles.add(scrollPane, gbc);

            // Mostrar la imagen en la tercera columna
            gbc.gridx = 2;
            gbc.gridy = 0;
            gbc.gridheight = GridBagConstraints.REMAINDER; // La imagen ocupará todas las filas
            gbc.anchor = GridBagConstraints.CENTER;

            String imagenNombre = alumno.getImagen();
            JLabel lblImagen = new JLabel("No hay imagen disponible.");
            if (imagenNombre != null && !imagenNombre.isEmpty()) {
                String rutaImagen = "imagenes/" + imagenNombre + ".jpg";
                ImageIcon imageIcon = new ImageIcon(rutaImagen);
                if (imageIcon.getIconWidth() > 0) {
                    Image image = imageIcon.getImage();
                    Image newImage = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                    lblImagen = new JLabel(new ImageIcon(newImage));
                }
            }
            panelDetalles.add(lblImagen, gbc);

            panelResumen.add(panelDetalles, BorderLayout.CENTER);

            // Cambiar el contenido del panel principal
            panelPrincipal.removeAll();
            panelPrincipal.add(panelResumen);
            panelPrincipal.revalidate();
            panelPrincipal.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "No se ha encontrado el alumno", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }





    private double calcularNotaMedia(int numeroAlumno) {
        // Obtener las asignaturas del alumno
        List<Asignatura> asignaturas = AsignaturaController.obtenerAsignaturas(numeroAlumno);
        
        if (asignaturas.isEmpty()) {
            return 0;  // Si no hay asignaturas, la nota media será 0
        }

        // Calcular la suma de todas las notas
        double sumaNotas = 0;
        for (Asignatura asignatura : asignaturas) {
            sumaNotas += asignatura.getNota();
        }

        // Calcular la nota media
        return sumaNotas / asignaturas.size();
    }

    private void mostrarAcercaDe() {
        // Información acerca de la aplicación
        JOptionPane.showMessageDialog(this, "Práctica 4 PSP - Versión 1.0 - Daniel Fernández Guzmán", "Acerca de", JOptionPane.INFORMATION_MESSAGE);
    }
}
